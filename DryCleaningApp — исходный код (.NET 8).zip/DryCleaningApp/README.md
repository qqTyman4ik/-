# DryCleaningApp — информационная система «Химчистка»

Учебный проект по ПМ.02 (студент Мещеряков М. Н., группа 3ИП-9-24).
Многослойная архитектура: `DryCleaningApp.DataAccess` (сущности, JSON-репозитории) →
`DryCleaningApp.BusinessLogic` (сервисы PriceList / Clients / Orders / Reports, исключения) →
`DryCleaningApp.Presentation` (консольный интерфейс, DI). Тесты — `tests/DryCleaningApp.Tests` (xUnit).

## Требования
.NET SDK 8.0 (https://dotnet.microsoft.com/download). Доступ к nuget.org при первой сборке.

## Запуск
```bash
dotnet build DryCleaningApp.sln
dotnet run --project src/DryCleaningApp.Presentation            # интерактивное меню
dotnet run --project src/DryCleaningApp.Presentation -- --demo  # сквозной сценарий без ввода
dotnet test DryCleaningApp.sln                                  # автотесты
dotnet test DryCleaningApp.sln --collect:"XPlat Code Coverage"  # тесты + покрытие (coverlet)
```
Данные хранятся в `bin/.../data/*.json`, журнал Trace — в `bin/.../logs/drycleaning.log`.
