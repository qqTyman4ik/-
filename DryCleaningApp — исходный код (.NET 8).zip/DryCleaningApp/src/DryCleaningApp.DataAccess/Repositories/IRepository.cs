using DryCleaningApp.DataAccess.Entities;

namespace DryCleaningApp.DataAccess.Repositories;

/// <summary>Контракт репозитория (интерфейс взаимодействия BLL → DAL).</summary>
/// <typeparam name="T">Тип сущности.</typeparam>
public interface IRepository<T>
    where T : class, IEntity
{
    IReadOnlyList<T> GetAll();
    T? GetById(int id);
    T Add(T entity);
    void Update(T entity);
    bool Delete(int id);
}

public interface IServiceTypeRepository : IRepository<ServiceType>
{
    IReadOnlyList<ServiceType> GetByCategory(ItemCategory category);
}

public interface IClientRepository : IRepository<Client>
{
    Client? FindByPhone(string phone);
}

public interface IOrderRepository : IRepository<Order>
{
    IReadOnlyList<Order> GetByClient(int clientId);
    IReadOnlyList<Order> GetByStatus(OrderStatus status);
}
