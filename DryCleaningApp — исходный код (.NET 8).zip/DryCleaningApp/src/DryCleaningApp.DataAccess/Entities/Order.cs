namespace DryCleaningApp.DataAccess.Entities;

/// <summary>Статус заказа. Переходы: Accepted → InProcessing → Ready → Issued; отмена возможна из Accepted и InProcessing.</summary>
public enum OrderStatus
{
    Accepted,
    InProcessing,
    Ready,
    Issued,
    Cancelled
}

/// <summary>Изделие, принятое в чистку (строка заказа).</summary>
public class OrderItem
{
    public int ServiceId { get; set; }
    public string ServiceName { get; set; } = string.Empty;
    public string ItemDescription { get; set; } = string.Empty;
    public int Quantity { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal LineTotal => Quantity * UnitPrice;
}

/// <summary>Заказ на чистку.</summary>
public class Order : IEntity
{
    public int Id { get; set; }
    public int ClientId { get; set; }
    public DateTime AcceptedAt { get; set; }
    public DateTime DueDate { get; set; }
    public DateTime? IssuedAt { get; set; }
    public bool IsUrgent { get; set; }
    public OrderStatus Status { get; set; } = OrderStatus.Accepted;
    public List<OrderItem> Items { get; set; } = new();
    public decimal Subtotal { get; set; }
    public decimal UrgencySurcharge { get; set; }
    public decimal Discount { get; set; }
    public decimal Total { get; set; }
}
