namespace DryCleaningApp.DataAccess.Entities;

/// <summary>Клиент химчистки.</summary>
public class Client : IEntity
{
    public int Id { get; set; }
    public string FullName { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public bool HasDiscountCard { get; set; }

    public override string ToString() => $"#{Id} {FullName}, тел. {Phone}{(HasDiscountCard ? ", карта постоянного клиента" : string.Empty)}";
}
