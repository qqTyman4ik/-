namespace DryCleaningApp.DataAccess.Entities;

/// <summary>Категория изделия.</summary>
public enum ItemCategory
{
    Clothing,
    Textile,
    Leather,
    Shoes
}

/// <summary>Услуга из прейскуранта химчистки.</summary>
public class ServiceType : IEntity
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public ItemCategory Category { get; set; }
    public decimal Price { get; set; }
    public int ProcessingDays { get; set; }
    public bool IsActive { get; set; } = true;

    public override string ToString() =>
        $"#{Id} {Name} [{Category}] — {Price:0.00} руб., {ProcessingDays} дн.{(IsActive ? string.Empty : " [не оказывается]")}";
}
