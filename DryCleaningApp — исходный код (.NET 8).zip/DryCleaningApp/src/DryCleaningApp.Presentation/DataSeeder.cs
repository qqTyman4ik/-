using DryCleaningApp.BusinessLogic.Interfaces;
using DryCleaningApp.DataAccess.Entities;

namespace DryCleaningApp.Presentation;

/// <summary>Заполняет пустое хранилище стартовыми данными (прейскурант и один клиент).</summary>
public class DataSeeder
{
    private readonly IPriceListService _priceList;
    private readonly IClientService _clients;

    public DataSeeder(IPriceListService priceList, IClientService clients)
    {
        _priceList = priceList;
        _clients = clients;
    }

    public void SeedIfEmpty()
    {
        if (_priceList.GetAll().Count == 0)
        {
            _priceList.AddService("Чистка пальто", ItemCategory.Clothing, 1200m, 3);
            _priceList.AddService("Чистка костюма", ItemCategory.Clothing, 1500m, 2);
            _priceList.AddService("Чистка пухового одеяла", ItemCategory.Textile, 1800m, 4);
            _priceList.AddService("Чистка кожаной куртки", ItemCategory.Leather, 3500m, 7);
            _priceList.AddService("Чистка обуви", ItemCategory.Shoes, 600m, 1);
        }

        if (_clients.GetAll().Count == 0)
        {
            _clients.Register("Петрова Анна Сергеевна", "+7 (903) 555-12-34", hasDiscountCard: true);
        }
    }
}
