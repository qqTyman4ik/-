using System.Globalization;
using DryCleaningApp.BusinessLogic.Exceptions;
using DryCleaningApp.BusinessLogic.Interfaces;
using DryCleaningApp.DataAccess.Entities;

namespace DryCleaningApp.Presentation;

/// <summary>Консольный интерфейс пользователя (слой представления).</summary>
public class ConsoleMenu
{
    private readonly IPriceListService _priceList;
    private readonly IClientService _clients;
    private readonly IOrderService _orders;
    private readonly IReportService _reports;
    private readonly Dictionary<string, Action> _actions;

    public ConsoleMenu(IPriceListService priceList, IClientService clients, IOrderService orders, IReportService reports)
    {
        _priceList = priceList;
        _clients = clients;
        _orders = orders;
        _reports = reports;
        _actions = new Dictionary<string, Action>
        {
            ["1"] = PrintPriceList,
            ["2"] = AddService,
            ["3"] = ServicesByCategory,
            ["4"] = RegisterClient,
            ["5"] = AcceptOrder,
            ["6"] = ChangeStatus,
            ["7"] = PrintOrders,
            ["8"] = PrintReports
        };
    }

    public void RunInteractive()
    {
        while (true)
        {
            Console.WriteLine();
            Console.WriteLine("=== ХИМЧИСТКА: учёт заказов ===");
            Console.WriteLine("1. Прейскурант            5. Принять заказ");
            Console.WriteLine("2. Добавить услугу        6. Изменить статус заказа");
            Console.WriteLine("3. Услуги по категории    7. Список заказов");
            Console.WriteLine("4. Зарегистрировать клиента  8. Отчёты");
            Console.WriteLine("0. Выход");
            Console.Write("Выбор: ");
            string choice = Console.ReadLine()?.Trim() ?? string.Empty;
            if (choice == "0")
            {
                return;
            }

            Safe(() => Dispatch(choice));
        }
    }

    /// <summary>Сквозной сценарий без участия пользователя — используется для проверки интеграции модулей.</summary>
    public int RunDemoScenario()
    {
        Console.WriteLine("--- Демонстрационный сценарий ---");
        PrintPriceList();
        var client = _clients.GetAll()[0];
        var order = _orders.AcceptOrder(client.Id, new[]
        {
            new OrderLine(1, "Пальто шерстяное, серое", 1),
            new OrderLine(5, "Ботинки замшевые", 2)
        }, isUrgent: true);
        PrintOrder(order);
        _orders.ChangeStatus(order.Id, OrderStatus.InProcessing);
        _orders.ChangeStatus(order.Id, OrderStatus.Ready);
        order = _orders.ChangeStatus(order.Id, OrderStatus.Issued);
        Console.WriteLine($"Заказ №{order.Id} выдан клиенту, статус {order.Status}");

        Console.WriteLine("Негативная проверка: отмена выданного заказа");
        Safe(() => _orders.Cancel(order.Id));
        Console.WriteLine("Негативная проверка: изделие без описания");
        Safe(() => _orders.AcceptOrder(client.Id, new[] { new OrderLine(1, "", 1) }, false));

        PrintReports();
        return 0;
    }

    private void Dispatch(string choice)
    {
        if (_actions.TryGetValue(choice, out var action))
        {
            action();
        }
        else
        {
            Console.WriteLine("Неизвестный пункт меню.");
        }
    }

    private void PrintPriceList()
    {
        Console.WriteLine("Прейскурант:");
        foreach (var service in _priceList.GetAll())
        {
            Console.WriteLine("  " + service);
        }
    }

    private void AddService()
    {
        string name = Ask("Название услуги");
        var category = Enum.Parse<ItemCategory>(Ask("Категория (Clothing/Textile/Leather/Shoes)"), ignoreCase: true);
        decimal price = ReadDecimal("Цена");
        int days = ReadInt("Срок, дней");
        Console.WriteLine("Добавлено: " + _priceList.AddService(name, category, price, days));
    }

    private void ServicesByCategory()
    {
        var category = Enum.Parse<ItemCategory>(Ask("Категория (Clothing/Textile/Leather/Shoes)"), ignoreCase: true);
        var found = _priceList.GetByCategory(category);
        Console.WriteLine(found.Count == 0 ? "Услуг нет." : string.Join(Environment.NewLine, found));
    }

    private void RegisterClient()
    {
        bool card = Ask("Есть карта постоянного клиента? (y/n)").Equals("y", StringComparison.OrdinalIgnoreCase);
        Console.WriteLine("Зарегистрирован: " + _clients.Register(Ask("ФИО"), Ask("Телефон"), card));
    }

    private void AcceptOrder()
    {
        int clientId = ReadInt("Id клиента");
        bool urgent = Ask("Срочный заказ? (y/n)").Equals("y", StringComparison.OrdinalIgnoreCase);
        var lines = new List<OrderLine>();
        while (true)
        {
            int serviceId = ReadInt("Id услуги (0 — закончить)");
            if (serviceId == 0)
            {
                break;
            }

            lines.Add(new OrderLine(serviceId, Ask("Описание изделия"), ReadInt("Количество")));
        }

        PrintOrder(_orders.AcceptOrder(clientId, lines, urgent));
    }

    private void ChangeStatus()
    {
        int id = ReadInt("Id заказа");
        var status = Enum.Parse<OrderStatus>(Ask("Новый статус (InProcessing/Ready/Issued/Cancelled)"), ignoreCase: true);
        PrintOrder(_orders.ChangeStatus(id, status));
    }

    private void PrintOrders()
    {
        foreach (var order in _orders.GetAll())
        {
            Console.WriteLine($"  №{order.Id} от {order.AcceptedAt:dd.MM.yyyy}, срок {order.DueDate:dd.MM.yyyy}, клиент {order.ClientId}, {order.Status}, итого {order.Total:0.00} руб.");
        }
    }

    private void PrintReports()
    {
        Console.WriteLine($"Выручка за месяц (выданные заказы): {_reports.GetRevenue(DateTime.Today.AddMonths(-1), DateTime.Now):0.00} руб.");
        var overdue = _reports.GetOverdueOrders(DateTime.Now);
        Console.WriteLine($"Просроченных заказов: {overdue.Count}");
        foreach (var order in overdue)
        {
            Console.WriteLine($"  №{order.Id}, срок был {order.DueDate:dd.MM.yyyy}, статус {order.Status}");
        }

        Console.WriteLine("Востребованные услуги:");
        foreach (var line in _reports.GetTopServices())
        {
            Console.WriteLine($"  {line.ServiceName}: {line.Quantity} изд., {line.Revenue:0.00} руб.");
        }
    }

    private static void PrintOrder(Order order)
    {
        Console.WriteLine($"Заказ №{order.Id} [{order.Status}] срочный: {(order.IsUrgent ? "да" : "нет")}, готовность {order.DueDate:dd.MM.yyyy}");
        foreach (var item in order.Items)
        {
            Console.WriteLine($"  {item.ServiceName} — {item.ItemDescription} x{item.Quantity} = {item.LineTotal:0.00}");
        }

        Console.WriteLine($"  Подытог {order.Subtotal:0.00}, срочность {order.UrgencySurcharge:0.00}, скидка {order.Discount:0.00}, ИТОГО {order.Total:0.00} руб.");
    }

    private static void Safe(Action action)
    {
        try
        {
            action();
        }
        catch (DryCleaningException ex)
        {
            Console.WriteLine("Ошибка: " + ex.Message);
        }
        catch (Exception ex) when (ex is FormatException or ArgumentException)
        {
            Console.WriteLine("Некорректный ввод: " + ex.Message);
        }
    }

    private static string Ask(string prompt)
    {
        Console.Write(prompt + ": ");
        return Console.ReadLine()?.Trim() ?? string.Empty;
    }

    private static int ReadInt(string prompt) => int.Parse(Ask(prompt), CultureInfo.InvariantCulture);

    private static decimal ReadDecimal(string prompt) => decimal.Parse(Ask(prompt).Replace(',', '.'), CultureInfo.InvariantCulture);
}
