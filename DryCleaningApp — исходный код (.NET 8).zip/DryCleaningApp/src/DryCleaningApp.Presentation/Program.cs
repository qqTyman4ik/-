using System.Diagnostics;
using DryCleaningApp.BusinessLogic.Interfaces;
using DryCleaningApp.BusinessLogic.Services;
using DryCleaningApp.DataAccess.Repositories;
using Microsoft.Extensions.DependencyInjection;

namespace DryCleaningApp.Presentation;

/// <summary>Точка входа: композиция слоёв (DI), настройка журнала Trace, запуск консольного меню.</summary>
public static class Program
{
    public static int Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        string baseDir = AppContext.BaseDirectory;
        string dataDir = Path.Combine(baseDir, "data");
        string logDir = Path.Combine(baseDir, "logs");
        Directory.CreateDirectory(logDir);

        Trace.Listeners.Add(new TextWriterTraceListener(Path.Combine(logDir, "drycleaning.log")));
        Trace.AutoFlush = true;
        Trace.WriteLine($"=== Запуск DryCleaningApp {DateTime.Now:dd.MM.yyyy HH:mm:ss} ===");

        using var provider = ConfigureServices(dataDir);
        new DataSeeder(provider.GetRequiredService<IPriceListService>(), provider.GetRequiredService<IClientService>()).SeedIfEmpty();

        var ui = new ConsoleMenu(
            provider.GetRequiredService<IPriceListService>(),
            provider.GetRequiredService<IClientService>(),
            provider.GetRequiredService<IOrderService>(),
            provider.GetRequiredService<IReportService>());

        if (args.Contains("--demo"))
        {
            return ui.RunDemoScenario();
        }

        ui.RunInteractive();
        return 0;
    }

    /// <summary>Регистрация зависимостей: интерфейсы BLL → реализации, интерфейсы DAL → JSON-репозитории.</summary>
    public static ServiceProvider ConfigureServices(string dataDir)
    {
        var services = new ServiceCollection();
        services.AddSingleton<IServiceTypeRepository>(_ => new ServiceTypeRepository(dataDir));
        services.AddSingleton<IClientRepository>(_ => new ClientRepository(dataDir));
        services.AddSingleton<IOrderRepository>(_ => new OrderRepository(dataDir));
        services.AddSingleton<IPriceListService, PriceListService>();
        services.AddSingleton<IClientService, ClientService>();
        services.AddSingleton<IOrderService>(sp => new OrderService(
            sp.GetRequiredService<IOrderRepository>(),
            sp.GetRequiredService<IServiceTypeRepository>(),
            sp.GetRequiredService<IClientRepository>()));
        services.AddSingleton<IReportService, ReportService>();
        return services.BuildServiceProvider();
    }
}
