using System.Diagnostics;
using DryCleaningApp.BusinessLogic.Exceptions;
using DryCleaningApp.BusinessLogic.Interfaces;
using DryCleaningApp.DataAccess.Entities;
using DryCleaningApp.DataAccess.Repositories;

namespace DryCleaningApp.BusinessLogic.Services;

/// <inheritdoc cref="IOrderService"/>
public class OrderService : IOrderService
{
    public const int MaxQuantityPerLine = 50;
    public const decimal UrgencyRate = 0.50m;
    public const decimal DiscountCardRate = 0.05m;

    private static readonly IReadOnlyDictionary<OrderStatus, OrderStatus[]> AllowedTransitions =
        new Dictionary<OrderStatus, OrderStatus[]>
        {
            [OrderStatus.Accepted] = new[] { OrderStatus.InProcessing, OrderStatus.Cancelled },
            [OrderStatus.InProcessing] = new[] { OrderStatus.Ready, OrderStatus.Cancelled },
            [OrderStatus.Ready] = new[] { OrderStatus.Issued },
            [OrderStatus.Issued] = Array.Empty<OrderStatus>(),
            [OrderStatus.Cancelled] = Array.Empty<OrderStatus>()
        };

    private readonly IOrderRepository _orders;
    private readonly IServiceTypeRepository _services;
    private readonly IClientRepository _clients;
    private readonly Func<DateTime> _clock;

    public OrderService(IOrderRepository orders, IServiceTypeRepository services, IClientRepository clients)
        : this(orders, services, clients, () => DateTime.Now)
    {
    }

    /// <summary>Конструктор с внедряемыми часами — используется в тестах для детерминированных дат.</summary>
    public OrderService(IOrderRepository orders, IServiceTypeRepository services, IClientRepository clients, Func<DateTime> clock)
    {
        _orders = orders ?? throw new ArgumentNullException(nameof(orders));
        _services = services ?? throw new ArgumentNullException(nameof(services));
        _clients = clients ?? throw new ArgumentNullException(nameof(clients));
        _clock = clock ?? throw new ArgumentNullException(nameof(clock));
    }

    public Order AcceptOrder(int clientId, IReadOnlyCollection<OrderLine> lines, bool isUrgent)
    {
        ArgumentNullException.ThrowIfNull(lines);
        var client = _clients.GetById(clientId) ?? throw new EntityNotFoundException("Клиент", clientId);
        if (lines.Count == 0)
        {
            throw new ValidationException("Заказ должен содержать хотя бы одно изделие.");
        }

        var now = _clock();
        var order = new Order { ClientId = clientId, AcceptedAt = now, IsUrgent = isUrgent };
        int maxDays = 0;
        foreach (var line in lines)
        {
            var service = ResolveService(line);
            order.Items.Add(new OrderItem
            {
                ServiceId = service.Id,
                ServiceName = service.Name,
                ItemDescription = line.ItemDescription.Trim(),
                Quantity = line.Quantity,
                UnitPrice = service.Price
            });
            maxDays = Math.Max(maxDays, service.ProcessingDays);
        }

        order.DueDate = now.Date.AddDays(CalculateProcessingDays(maxDays, isUrgent));
        CalculateTotals(order, client.HasDiscountCard);
        _orders.Add(order);
        Trace.WriteLine($"[BLL] Принят заказ №{order.Id}, клиент {clientId}, срок {order.DueDate:dd.MM.yyyy}, сумма {order.Total:0.00}");
        return order;
    }

    public Order ChangeStatus(int orderId, OrderStatus newStatus)
    {
        var order = GetById(orderId);
        if (!AllowedTransitions[order.Status].Contains(newStatus))
        {
            throw InvalidOrderStateException.ForTransition(order.Status.ToString(), newStatus.ToString());
        }

        Debug.WriteLine($"[BLL] Заказ №{orderId}: {order.Status} -> {newStatus}");
        order.Status = newStatus;
        if (newStatus == OrderStatus.Issued)
        {
            order.IssuedAt = _clock();
        }

        _orders.Update(order);
        return order;
    }

    public Order Cancel(int orderId) => ChangeStatus(orderId, OrderStatus.Cancelled);

    public IReadOnlyList<Order> GetAll() => _orders.GetAll();

    public Order GetById(int orderId) =>
        _orders.GetById(orderId) ?? throw new EntityNotFoundException("Заказ", orderId);

    /// <summary>Срочный заказ выполняется вдвое быстрее (с округлением вверх), но не менее чем за 1 день.</summary>
    public static int CalculateProcessingDays(int maxServiceDays, bool isUrgent) =>
        isUrgent ? Math.Max(1, (int)Math.Ceiling(maxServiceDays / 2.0)) : maxServiceDays;

    /// <summary>Рассчитывает подытог, надбавку за срочность, скидку по карте и итог.</summary>
    public static void CalculateTotals(Order order, bool hasDiscountCard)
    {
        ArgumentNullException.ThrowIfNull(order);
        order.Subtotal = order.Items.Sum(i => i.LineTotal);
        order.UrgencySurcharge = order.IsUrgent ? Math.Round(order.Subtotal * UrgencyRate, 2) : 0m;
        decimal baseForDiscount = order.Subtotal + order.UrgencySurcharge;
        order.Discount = hasDiscountCard ? Math.Round(baseForDiscount * DiscountCardRate, 2) : 0m;
        order.Total = baseForDiscount - order.Discount;
    }

    private ServiceType ResolveService(OrderLine line)
    {
        if (string.IsNullOrWhiteSpace(line.ItemDescription))
        {
            throw new ValidationException("Описание изделия обязательно (например, «пальто шерстяное, серое»).");
        }

        if (line.Quantity < 1 || line.Quantity > MaxQuantityPerLine)
        {
            throw new ValidationException($"Количество изделий в строке должно быть от 1 до {MaxQuantityPerLine}.");
        }

        var service = _services.GetById(line.ServiceId) ?? throw new EntityNotFoundException("Услуга", line.ServiceId);
        if (!service.IsActive)
        {
            throw ServiceUnavailableException.ForService(service.Name);
        }

        return service;
    }
}
