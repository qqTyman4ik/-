using System.Diagnostics;
using DryCleaningApp.BusinessLogic.Exceptions;
using DryCleaningApp.BusinessLogic.Interfaces;
using DryCleaningApp.DataAccess.Entities;
using DryCleaningApp.DataAccess.Repositories;

namespace DryCleaningApp.BusinessLogic.Services;

/// <inheritdoc cref="IPriceListService"/>
public class PriceListService : IPriceListService
{
    public const decimal MinPrice = 50m;
    public const decimal MaxPrice = 20000m;
    public const int MaxProcessingDays = 30;

    private readonly IServiceTypeRepository _services;

    public PriceListService(IServiceTypeRepository services)
    {
        _services = services ?? throw new ArgumentNullException(nameof(services));
    }

    public IReadOnlyList<ServiceType> GetAll(bool onlyActive = false)
    {
        var all = _services.GetAll();
        return onlyActive ? all.Where(s => s.IsActive).ToList() : all;
    }

    public IReadOnlyList<ServiceType> GetByCategory(ItemCategory category) => _services.GetByCategory(category);

    public ServiceType AddService(string name, ItemCategory category, decimal price, int processingDays)
    {
        if (string.IsNullOrWhiteSpace(name))
        {
            throw new ValidationException("Название услуги обязательно.");
        }

        ValidatePrice(price);
        if (processingDays < 1 || processingDays > MaxProcessingDays)
        {
            throw new ValidationException($"Срок выполнения должен быть от 1 до {MaxProcessingDays} дней.");
        }

        if (_services.GetAll().Any(s => s.Name.Equals(name.Trim(), StringComparison.OrdinalIgnoreCase)))
        {
            throw new ValidationException($"Услуга «{name}» уже есть в прейскуранте.");
        }

        var service = _services.Add(new ServiceType { Name = name.Trim(), Category = category, Price = price, ProcessingDays = processingDays });
        Trace.WriteLine($"[BLL] Добавлена услуга {service}");
        return service;
    }

    public void SetActive(int serviceId, bool isActive)
    {
        var service = GetServiceOrThrow(serviceId);
        service.IsActive = isActive;
        _services.Update(service);
    }

    public void ChangePrice(int serviceId, decimal newPrice)
    {
        ValidatePrice(newPrice);
        var service = GetServiceOrThrow(serviceId);
        service.Price = newPrice;
        _services.Update(service);
    }

    private static void ValidatePrice(decimal price)
    {
        if (price < MinPrice || price > MaxPrice)
        {
            throw new ValidationException($"Цена должна быть в диапазоне от {MinPrice} до {MaxPrice} руб.");
        }
    }

    private ServiceType GetServiceOrThrow(int serviceId) =>
        _services.GetById(serviceId) ?? throw new EntityNotFoundException("Услуга", serviceId);
}
