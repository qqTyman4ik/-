using System.Text.RegularExpressions;
using DryCleaningApp.BusinessLogic.Exceptions;
using DryCleaningApp.BusinessLogic.Interfaces;
using DryCleaningApp.DataAccess.Entities;
using DryCleaningApp.DataAccess.Repositories;

namespace DryCleaningApp.BusinessLogic.Services;

/// <inheritdoc cref="IClientService"/>
public partial class ClientService : IClientService
{
    private readonly IClientRepository _clients;

    public ClientService(IClientRepository clients)
    {
        _clients = clients ?? throw new ArgumentNullException(nameof(clients));
    }

    public IReadOnlyList<Client> GetAll() => _clients.GetAll();

    public Client Register(string fullName, string phone, bool hasDiscountCard)
    {
        if (string.IsNullOrWhiteSpace(fullName))
        {
            throw new ValidationException("Имя клиента обязательно.");
        }

        string normalizedPhone = NormalizePhone(phone);
        if (_clients.FindByPhone(normalizedPhone) is not null)
        {
            throw new ValidationException($"Клиент с телефоном {normalizedPhone} уже зарегистрирован.");
        }

        return _clients.Add(new Client
        {
            FullName = fullName.Trim(),
            Phone = normalizedPhone,
            HasDiscountCard = hasDiscountCard
        });
    }

    public Client GetById(int clientId) =>
        _clients.GetById(clientId) ?? throw new EntityNotFoundException("Клиент", clientId);

    /// <summary>Приводит телефон к виду +7XXXXXXXXXX; принимает форматы 8XXXXXXXXXX и +7XXXXXXXXXX.</summary>
    public static string NormalizePhone(string? phone)
    {
        string digits = DigitsOnly().Replace(phone ?? string.Empty, string.Empty);
        if (digits.Length == 11 && (digits[0] == '7' || digits[0] == '8'))
        {
            return "+7" + digits[1..];
        }

        throw new ValidationException("Телефон должен содержать 11 цифр и начинаться с 8 или +7.");
    }

    [GeneratedRegex(@"\D")]
    private static partial Regex DigitsOnly();
}
