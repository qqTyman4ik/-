using DryCleaningApp.BusinessLogic.Interfaces;
using DryCleaningApp.DataAccess.Entities;
using DryCleaningApp.DataAccess.Repositories;

namespace DryCleaningApp.BusinessLogic.Services;

/// <inheritdoc cref="IReportService"/>
public class ReportService : IReportService
{
    private readonly IOrderRepository _orders;

    public ReportService(IOrderRepository orders)
    {
        _orders = orders ?? throw new ArgumentNullException(nameof(orders));
    }

    public decimal GetRevenue(DateTime periodStart, DateTime periodEnd) =>
        _orders.GetByStatus(OrderStatus.Issued)
            .Where(o => o.IssuedAt.HasValue && o.IssuedAt.Value >= periodStart && o.IssuedAt.Value <= periodEnd)
            .Sum(o => o.Total);

    public IReadOnlyList<Order> GetOverdueOrders(DateTime asOf) =>
        _orders.GetAll()
            .Where(o => o.Status is OrderStatus.Accepted or OrderStatus.InProcessing && o.DueDate < asOf.Date)
            .OrderBy(o => o.DueDate)
            .ToList();

    public IReadOnlyList<ServiceUsageLine> GetTopServices(int top = 5) =>
        _orders.GetAll()
            .Where(o => o.Status != OrderStatus.Cancelled)
            .SelectMany(o => o.Items)
            .GroupBy(i => i.ServiceName)
            .Select(g => new ServiceUsageLine(g.Key, g.Sum(i => i.Quantity), g.Sum(i => i.LineTotal)))
            .OrderByDescending(s => s.Quantity)
            .Take(top)
            .ToList();
}
