using DryCleaningApp.DataAccess.Entities;

namespace DryCleaningApp.BusinessLogic.Interfaces;

/// <summary>Модуль PriceList — прейскурант услуг.</summary>
public interface IPriceListService
{
    IReadOnlyList<ServiceType> GetAll(bool onlyActive = false);
    IReadOnlyList<ServiceType> GetByCategory(ItemCategory category);
    ServiceType AddService(string name, ItemCategory category, decimal price, int processingDays);
    void SetActive(int serviceId, bool isActive);
    void ChangePrice(int serviceId, decimal newPrice);
}

/// <summary>Модуль Clients — учёт клиентов.</summary>
public interface IClientService
{
    IReadOnlyList<Client> GetAll();
    Client Register(string fullName, string phone, bool hasDiscountCard);
    Client GetById(int clientId);
}

/// <summary>Изделие, передаваемое из UI в сервис заказов.</summary>
public record OrderLine(int ServiceId, string ItemDescription, int Quantity);

/// <summary>Модуль Orders — приём, обработка и выдача заказов.</summary>
public interface IOrderService
{
    Order AcceptOrder(int clientId, IReadOnlyCollection<OrderLine> lines, bool isUrgent);
    Order ChangeStatus(int orderId, OrderStatus newStatus);
    Order Cancel(int orderId);
    IReadOnlyList<Order> GetAll();
    Order GetById(int orderId);
}

/// <summary>Строка отчёта о востребованности услуг.</summary>
public record ServiceUsageLine(string ServiceName, int Quantity, decimal Revenue);

/// <summary>Модуль Reports — отчётность.</summary>
public interface IReportService
{
    decimal GetRevenue(DateTime periodStart, DateTime periodEnd);
    IReadOnlyList<Order> GetOverdueOrders(DateTime asOf);
    IReadOnlyList<ServiceUsageLine> GetTopServices(int top = 5);
}
