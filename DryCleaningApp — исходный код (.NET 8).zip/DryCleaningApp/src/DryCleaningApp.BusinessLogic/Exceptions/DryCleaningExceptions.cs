namespace DryCleaningApp.BusinessLogic.Exceptions;

/// <summary>Базовое исключение бизнес-логики химчистки.</summary>
public class DryCleaningException : Exception
{
    public DryCleaningException() : base("Ошибка бизнес-логики.") { }

    public DryCleaningException(string message) : base(message) { }

    public DryCleaningException(string message, Exception innerException) : base(message, innerException) { }
}

/// <summary>Нарушение правил валидации входных данных.</summary>
public class ValidationException : DryCleaningException
{
    public ValidationException() : base("Некорректные входные данные.") { }

    public ValidationException(string message) : base(message) { }

    public ValidationException(string message, Exception innerException) : base(message, innerException) { }
}

/// <summary>Сущность не найдена в хранилище.</summary>
public class EntityNotFoundException : DryCleaningException
{
    public EntityNotFoundException() : base("Объект не найден.") { }

    public EntityNotFoundException(string message) : base(message) { }

    public EntityNotFoundException(string message, Exception innerException) : base(message, innerException) { }

    public EntityNotFoundException(string entityName, int id)
        : base($"{entityName} с идентификатором {id} не найден(а).") { }
}

/// <summary>Услуга временно не оказывается.</summary>
public class ServiceUnavailableException : DryCleaningException
{
    public ServiceUnavailableException() : base("Услуга не оказывается.") { }

    public ServiceUnavailableException(string message) : base(message) { }

    public ServiceUnavailableException(string message, Exception innerException) : base(message, innerException) { }

    public static ServiceUnavailableException ForService(string service) => new($"Услуга «{service}» временно не оказывается.");
}

/// <summary>Недопустимый переход статуса заказа.</summary>
public class InvalidOrderStateException : DryCleaningException
{
    public InvalidOrderStateException() : base("Недопустимый переход статуса заказа.") { }

    public InvalidOrderStateException(string message) : base(message) { }

    public InvalidOrderStateException(string message, Exception innerException) : base(message, innerException) { }

    public static InvalidOrderStateException ForTransition(string current, string target) =>
        new($"Переход заказа из статуса «{current}» в «{target}» недопустим.");
}
