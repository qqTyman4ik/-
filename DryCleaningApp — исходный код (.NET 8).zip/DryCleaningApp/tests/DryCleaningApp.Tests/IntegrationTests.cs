using DryCleaningApp.BusinessLogic.Interfaces;
using DryCleaningApp.DataAccess.Entities;
using DryCleaningApp.DataAccess.Repositories;
using DryCleaningApp.Presentation;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace DryCleaningApp.Tests;

/// <summary>Интеграционные тесты: BLL + DAL (JSON-файлы во временном каталоге) + композиция DI из Presentation.</summary>
public sealed class IntegrationTests : IDisposable
{
    private readonly string _dir = Path.Combine(Path.GetTempPath(), "drycleaning-tests-" + Guid.NewGuid().ToString("N"));

    public void Dispose()
    {
        if (Directory.Exists(_dir))
        {
            Directory.Delete(_dir, true);
        }

        GC.SuppressFinalize(this);
    }

    [Fact] // ИТ-01
    public void JsonRepository_AddThenReload_PersistsData()
    {
        var repo = new ServiceTypeRepository(_dir);
        repo.Add(new ServiceType { Name = "Чистка пальто", Price = 1200m, ProcessingDays = 3 });
        var reloaded = new ServiceTypeRepository(_dir);
        Assert.Single(reloaded.GetAll());
        Assert.Equal("Чистка пальто", reloaded.GetById(1)!.Name);
    }

    [Fact] // ИТ-02 сквозной сценарий через DI
    public void EndToEnd_AcceptOrderThroughServices_SavedToJson()
    {
        using var provider = Program.ConfigureServices(_dir);
        new DataSeeder(provider.GetRequiredService<IPriceListService>(), provider.GetRequiredService<IClientService>()).SeedIfEmpty();
        var orders = provider.GetRequiredService<IOrderService>();

        var order = orders.AcceptOrder(1, new[] { new OrderLine(2, "Костюм тёмно-синий", 1) }, isUrgent: false);
        orders.ChangeStatus(order.Id, OrderStatus.InProcessing);

        var fromDisk = new OrderRepository(_dir).GetById(order.Id);
        Assert.NotNull(fromDisk);
        Assert.Equal(OrderStatus.InProcessing, fromDisk!.Status);
        Assert.Equal(1425m, fromDisk.Total); // 1500 − 5 % по карте клиента из DataSeeder
        Assert.True(File.Exists(Path.Combine(_dir, "orders.json")));
    }

    [Fact] // ИТ-03 отчёт по данным из файла
    public void Report_AfterIssuedOrder_RevenueMatches()
    {
        using var provider = Program.ConfigureServices(_dir);
        new DataSeeder(provider.GetRequiredService<IPriceListService>(), provider.GetRequiredService<IClientService>()).SeedIfEmpty();
        var orders = provider.GetRequiredService<IOrderService>();
        var order = orders.AcceptOrder(1, new[] { new OrderLine(5, "Туфли", 2) }, false);
        orders.ChangeStatus(order.Id, OrderStatus.InProcessing);
        orders.ChangeStatus(order.Id, OrderStatus.Ready);
        orders.ChangeStatus(order.Id, OrderStatus.Issued);

        var reports = provider.GetRequiredService<IReportService>();
        Assert.Equal(1140m, reports.GetRevenue(DateTime.Today, DateTime.Now.AddMinutes(1))); // 1200 − 5 %
    }
}
