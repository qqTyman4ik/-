using DryCleaningApp.BusinessLogic.Exceptions;
using DryCleaningApp.BusinessLogic.Services;
using DryCleaningApp.DataAccess.Entities;
using Xunit;

namespace DryCleaningApp.Tests;

public class PriceListServiceTests
{
    private readonly PriceListService _service = new(new InMemoryServiceTypeRepository());

    [Fact] // ТК-01
    public void AddService_ValidData_AppearsInPriceList()
    {
        var s = _service.AddService("Чистка пальто", ItemCategory.Clothing, 1200m, 3);
        Assert.Equal(1, s.Id);
        Assert.Single(_service.GetAll());
    }

    [Theory] // ТК-02
    [InlineData(49)]
    [InlineData(20001)]
    public void AddService_PriceOutOfRange_ThrowsValidation(decimal price) =>
        Assert.Throws<ValidationException>(() => _service.AddService("Тест", ItemCategory.Shoes, price, 1));

    [Theory] // ТК-03 граничные
    [InlineData(50, 1)]
    [InlineData(20000, 30)]
    public void AddService_BoundaryValues_Succeeds(decimal price, int days) =>
        Assert.NotNull(_service.AddService("Тест", ItemCategory.Shoes, price, days));

    [Theory] // ТК-04
    [InlineData(0)]
    [InlineData(31)]
    public void AddService_DaysOutOfRange_ThrowsValidation(int days) =>
        Assert.Throws<ValidationException>(() => _service.AddService("Тест", ItemCategory.Shoes, 500m, days));

    [Fact] // ТК-05
    public void AddService_EmptyName_ThrowsValidation() =>
        Assert.Throws<ValidationException>(() => _service.AddService(" ", ItemCategory.Shoes, 500m, 1));

    [Fact] // ТК-06
    public void AddService_DuplicateName_ThrowsValidation()
    {
        _service.AddService("Чистка обуви", ItemCategory.Shoes, 600m, 1);
        Assert.Throws<ValidationException>(() => _service.AddService("чистка ОБУВИ", ItemCategory.Shoes, 700m, 1));
    }

    [Fact] // ТК-07
    public void GetByCategory_ReturnsOnlyMatching()
    {
        _service.AddService("Чистка пальто", ItemCategory.Clothing, 1200m, 3);
        _service.AddService("Чистка обуви", ItemCategory.Shoes, 600m, 1);
        Assert.Single(_service.GetByCategory(ItemCategory.Shoes));
    }

    [Fact] // ТК-08
    public void SetActive_UnknownId_ThrowsNotFound() =>
        Assert.Throws<EntityNotFoundException>(() => _service.SetActive(42, false));

    [Fact] // ТК-09
    public void GetAll_OnlyActive_FiltersInactive()
    {
        var s = _service.AddService("Чистка пальто", ItemCategory.Clothing, 1200m, 3);
        _service.AddService("Чистка обуви", ItemCategory.Shoes, 600m, 1);
        _service.SetActive(s.Id, false);
        Assert.Single(_service.GetAll(onlyActive: true));
    }
}
