using DryCleaningApp.BusinessLogic.Exceptions;
using DryCleaningApp.BusinessLogic.Interfaces;
using DryCleaningApp.BusinessLogic.Services;
using DryCleaningApp.DataAccess.Entities;
using Xunit;

namespace DryCleaningApp.Tests;

public class OrderServiceTests
{
    private static readonly DateTime FixedNow = new(2026, 10, 5, 10, 0, 0);

    private readonly InMemoryServiceTypeRepository _services = new();
    private readonly InMemoryClientRepository _clients = new();
    private readonly InMemoryOrderRepository _orders = new();
    private readonly OrderService _service;

    public OrderServiceTests()
    {
        _services.Add(new ServiceType { Name = "Чистка пальто", Price = 1200m, ProcessingDays = 3 });
        _services.Add(new ServiceType { Name = "Чистка обуви", Price = 600m, ProcessingDays = 1 });
        _services.Add(new ServiceType { Name = "Чистка кожаной куртки", Price = 3500m, ProcessingDays = 7, IsActive = false });
        _clients.Add(new Client { FullName = "Петрова", Phone = "+79035551234", HasDiscountCard = false });
        _clients.Add(new Client { FullName = "С картой", Phone = "+79030000000", HasDiscountCard = true });
        _service = new OrderService(_orders, _services, _clients, () => FixedNow);
    }

    [Fact] // ТК-14 позитивный
    public void AcceptOrder_TwoLines_CalculatesTotalsAndDueDate()
    {
        var order = _service.AcceptOrder(1, new[] { new OrderLine(1, "Пальто серое", 1), new OrderLine(2, "Ботинки", 2) }, false);
        Assert.Equal(2400m, order.Subtotal);
        Assert.Equal(0m, order.UrgencySurcharge);
        Assert.Equal(2400m, order.Total);
        Assert.Equal(new DateTime(2026, 10, 8), order.DueDate); // max(3, 1) дней
        Assert.Equal(OrderStatus.Accepted, order.Status);
    }

    [Fact] // ТК-15 срочный заказ: +50 % и срок вдвое короче (3 → 2 дня)
    public void AcceptOrder_Urgent_AppliesSurchargeAndShortensDueDate()
    {
        var order = _service.AcceptOrder(1, new[] { new OrderLine(1, "Пальто", 1) }, true);
        Assert.Equal(600m, order.UrgencySurcharge);
        Assert.Equal(1800m, order.Total);
        Assert.Equal(new DateTime(2026, 10, 7), order.DueDate);
    }

    [Fact] // ТК-16 скидка 5 % по карте считается от суммы с надбавкой
    public void AcceptOrder_DiscountCard_AppliesFivePercent()
    {
        var order = _service.AcceptOrder(2, new[] { new OrderLine(1, "Пальто", 1) }, true);
        Assert.Equal(90m, order.Discount); // (1200 + 600) * 0.05
        Assert.Equal(1710m, order.Total);
    }

    [Theory] // ТК-17 расчёт срока
    [InlineData(1, true, 1)]
    [InlineData(3, true, 2)]
    [InlineData(7, true, 4)]
    [InlineData(7, false, 7)]
    public void CalculateProcessingDays_Cases(int days, bool urgent, int expected) =>
        Assert.Equal(expected, OrderService.CalculateProcessingDays(days, urgent));

    [Fact] // ТК-18 негативный
    public void AcceptOrder_EmptyLines_ThrowsValidation() =>
        Assert.Throws<ValidationException>(() => _service.AcceptOrder(1, Array.Empty<OrderLine>(), false));

    [Theory] // ТК-19 граничные количества
    [InlineData(0)]
    [InlineData(51)]
    public void AcceptOrder_QuantityOutOfRange_ThrowsValidation(int qty) =>
        Assert.Throws<ValidationException>(() => _service.AcceptOrder(1, new[] { new OrderLine(1, "Пальто", qty) }, false));

    [Fact] // ТК-20
    public void AcceptOrder_EmptyDescription_ThrowsValidation() =>
        Assert.Throws<ValidationException>(() => _service.AcceptOrder(1, new[] { new OrderLine(1, "  ", 1) }, false));

    [Fact] // ТК-21
    public void AcceptOrder_InactiveService_ThrowsServiceUnavailable() =>
        Assert.Throws<ServiceUnavailableException>(() => _service.AcceptOrder(1, new[] { new OrderLine(3, "Куртка", 1) }, false));

    [Fact] // ТК-22
    public void AcceptOrder_UnknownClient_ThrowsNotFound() =>
        Assert.Throws<EntityNotFoundException>(() => _service.AcceptOrder(99, new[] { new OrderLine(1, "Пальто", 1) }, false));

    [Fact] // ТК-23 жизненный цикл
    public void ChangeStatus_FullLifecycle_SetsIssuedAt()
    {
        var order = _service.AcceptOrder(1, new[] { new OrderLine(2, "Ботинки", 1) }, false);
        _service.ChangeStatus(order.Id, OrderStatus.InProcessing);
        _service.ChangeStatus(order.Id, OrderStatus.Ready);
        var issued = _service.ChangeStatus(order.Id, OrderStatus.Issued);
        Assert.Equal(OrderStatus.Issued, issued.Status);
        Assert.Equal(FixedNow, issued.IssuedAt);
    }

    [Fact] // ТК-24 негативный переход
    public void ChangeStatus_AcceptedToIssued_ThrowsInvalidState()
    {
        var order = _service.AcceptOrder(1, new[] { new OrderLine(2, "Ботинки", 1) }, false);
        Assert.Throws<InvalidOrderStateException>(() => _service.ChangeStatus(order.Id, OrderStatus.Issued));
    }

    [Fact] // ТК-25 отмена готового заказа запрещена
    public void Cancel_ReadyOrder_ThrowsInvalidState()
    {
        var order = _service.AcceptOrder(1, new[] { new OrderLine(2, "Ботинки", 1) }, false);
        _service.ChangeStatus(order.Id, OrderStatus.InProcessing);
        _service.ChangeStatus(order.Id, OrderStatus.Ready);
        Assert.Throws<InvalidOrderStateException>(() => _service.Cancel(order.Id));
    }
}
