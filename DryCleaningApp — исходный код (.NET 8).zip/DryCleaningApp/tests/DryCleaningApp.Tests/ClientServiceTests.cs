using DryCleaningApp.BusinessLogic.Exceptions;
using DryCleaningApp.BusinessLogic.Services;
using Xunit;

namespace DryCleaningApp.Tests;

public class ClientServiceTests
{
    private readonly ClientService _service = new(new InMemoryClientRepository());

    [Theory] // ТК-10
    [InlineData("8 903 555 12 34", "+79035551234")]
    [InlineData("+7 (903) 555-12-34", "+79035551234")]
    public void NormalizePhone_ValidFormats_ReturnsCanonical(string input, string expected) =>
        Assert.Equal(expected, ClientService.NormalizePhone(input));

    [Theory] // ТК-11
    [InlineData("12345")]
    [InlineData("")]
    [InlineData("+1 903 555 12 34")]
    public void NormalizePhone_Invalid_ThrowsValidation(string input) =>
        Assert.Throws<ValidationException>(() => ClientService.NormalizePhone(input));

    [Fact] // ТК-12
    public void Register_DuplicatePhone_ThrowsValidation()
    {
        _service.Register("Петрова А.С.", "89035551234", true);
        Assert.Throws<ValidationException>(() => _service.Register("Сидоров С.С.", "+7 903 555-12-34", false));
    }

    [Fact] // ТК-13
    public void GetById_Unknown_ThrowsNotFound() =>
        Assert.Throws<EntityNotFoundException>(() => _service.GetById(7));
}
