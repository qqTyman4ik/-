using DryCleaningApp.BusinessLogic.Services;
using DryCleaningApp.DataAccess.Entities;
using Xunit;

namespace DryCleaningApp.Tests;

public class ReportServiceTests
{
    private readonly InMemoryOrderRepository _repo = new();

    [Fact] // ТК-26
    public void GetRevenue_CountsOnlyIssuedOrdersInPeriod()
    {
        _repo.Add(new Order { Status = OrderStatus.Issued, IssuedAt = new DateTime(2026, 10, 3), Total = 1000m });
        _repo.Add(new Order { Status = OrderStatus.Issued, IssuedAt = new DateTime(2026, 9, 1), Total = 700m });
        _repo.Add(new Order { Status = OrderStatus.Ready, Total = 500m });
        var revenue = new ReportService(_repo).GetRevenue(new DateTime(2026, 10, 1), new DateTime(2026, 10, 31));
        Assert.Equal(1000m, revenue);
    }

    [Fact] // ТК-27
    public void GetOverdueOrders_ReturnsUnfinishedPastDue()
    {
        _repo.Add(new Order { Status = OrderStatus.InProcessing, DueDate = new DateTime(2026, 10, 1) });
        _repo.Add(new Order { Status = OrderStatus.Ready, DueDate = new DateTime(2026, 10, 1) });
        _repo.Add(new Order { Status = OrderStatus.Accepted, DueDate = new DateTime(2026, 10, 20) });
        var overdue = new ReportService(_repo).GetOverdueOrders(new DateTime(2026, 10, 5));
        Assert.Single(overdue);
        Assert.Equal(1, overdue[0].Id);
    }

    [Fact] // ТК-28
    public void GetTopServices_ExcludesCancelledAndAggregates()
    {
        _repo.Add(new Order { Status = OrderStatus.Issued, Items = { new OrderItem { ServiceName = "Чистка обуви", Quantity = 2, UnitPrice = 600m } } });
        _repo.Add(new Order { Status = OrderStatus.Accepted, Items = { new OrderItem { ServiceName = "Чистка обуви", Quantity = 1, UnitPrice = 600m } } });
        _repo.Add(new Order { Status = OrderStatus.Cancelled, Items = { new OrderItem { ServiceName = "Чистка пальто", Quantity = 5, UnitPrice = 1200m } } });
        var top = new ReportService(_repo).GetTopServices();
        Assert.Single(top);
        Assert.Equal(3, top[0].Quantity);
        Assert.Equal(1800m, top[0].Revenue);
    }
}
