using DryCleaningApp.DataAccess.Entities;
using DryCleaningApp.DataAccess.Repositories;

namespace DryCleaningApp.Tests;

/// <summary>Репозиторий в памяти — заглушка DAL для модульных тестов BLL.</summary>
public class InMemoryRepository<T> : IRepository<T>
    where T : class, IEntity
{
    protected List<T> Items { get; } = new();

    public IReadOnlyList<T> GetAll() => Items.ToList();
    public T? GetById(int id) => Items.FirstOrDefault(x => x.Id == id);
    public T Add(T entity)
    {
        entity.Id = Items.Count == 0 ? 1 : Items.Max(x => x.Id) + 1;
        Items.Add(entity);
        return entity;
    }

    public void Update(T entity)
    {
        int i = Items.FindIndex(x => x.Id == entity.Id);
        Items[i] = entity;
    }

    public bool Delete(int id) => Items.RemoveAll(x => x.Id == id) > 0;
}

public class InMemoryServiceTypeRepository : InMemoryRepository<ServiceType>, IServiceTypeRepository
{
    public IReadOnlyList<ServiceType> GetByCategory(ItemCategory category) => Items.Where(s => s.Category == category).ToList();
}

public class InMemoryClientRepository : InMemoryRepository<Client>, IClientRepository
{
    public Client? FindByPhone(string phone) => Items.FirstOrDefault(c => c.Phone == phone);
}

public class InMemoryOrderRepository : InMemoryRepository<Order>, IOrderRepository
{
    public IReadOnlyList<Order> GetByClient(int clientId) => Items.Where(o => o.ClientId == clientId).ToList();
    public IReadOnlyList<Order> GetByStatus(OrderStatus status) => Items.Where(o => o.Status == status).ToList();
}
